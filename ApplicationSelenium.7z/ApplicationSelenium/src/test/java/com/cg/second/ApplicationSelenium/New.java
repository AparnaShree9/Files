package com.cg.second.ApplicationSelenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

public class New {

	public static void main(String[] args) {
		
				System.setProperty("webdriver.firefox.driver", "C:\\Program Files (x86)\\Mozilla Firefox");
		    	WebDriver driver=new FirefoxDriver();
		    	
		/*		File pathToBinary = new File("C:/Program Files/Mozilla Firefox/firefox.exe");
				FirefoxProfile firefoxProfile = new FirefoxProfile();
				FirefoxBinary binary = new FirefoxBinary(pathToBinary);
						
				WebDriver driver = new FirefoxDriver(binary,firefoxProfile);
				*/
				driver.get("D:\\\\BDD\\\\application.html");
				
				String parentWindow = driver.getWindowHandle().toString();
				
				driver.findElement(By.linkText("click")).click();
				driver.switchTo().window("PopupWindow");
			//	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				driver.close();
				
				driver.switchTo().window(parentWindow);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				//driver.close(); 
	}

}
