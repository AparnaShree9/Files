package com.cg.second.ApplicationSelenium;

import java.util.ArrayList;

import java.util.List;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefName {
  
	
	
	@Given("^I am on web Page$")
	public void i_am_on_web_Page() throws Throwable {
		
	}
	
	List<String>name = new ArrayList<String>();
	@When("^entered first name and entered last name$")
	public void entered_first_name_and_entered_last_name(DataTable arg1) throws Throwable {
	   
	   
	}


	@Then("^name is generated$")
	public void name_is_generated() throws Throwable {
	  
	}
}
