package com.cg.second.ApplicationSelenium;

import org.openqa.selenium.WebElement;

public class PageFactoryForm {

	
WebElement firstName;
WebElement lastName;	
WebElement mobileNumber;	
WebElement button;	
}
