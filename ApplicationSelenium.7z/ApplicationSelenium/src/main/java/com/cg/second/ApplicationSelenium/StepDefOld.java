package com.cg.second.ApplicationSelenium;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefOld {
	@Given("^I am on web Page$")
	public void i_am_on_web_Page() throws Throwable {
	  
	}

	@When("^entered firstName$")
	public void entered_firstName() throws Throwable {
	    
		System.out.println("Your first Name");
		
	}

	@Then("^<first name> is checked$")
	public void first_name_is_checked(DataTable arg1) throws Throwable {
	  
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.xpath("/html/body/div/form/input[1]"));
    	 List<String> list = arg1.asList(String.class);

 		List<String> l1 = arg1.asList(String.class);
 		//l1.stream().forEach(System.out::println);
 		long c = l1.stream().count();

 		for(int i=0 ; i<c; i++)
 		{
 			String a = list.get(i);
 			

 			
 			if(a.matches("[A-z][A-Za-z]")){

 				element.sendKeys(a);
 				System.out.println("First Name (valid): " + a);
 			assertTrue(a.matches("[A-z][A-Za-z]"));
 			}
 		
 			else {
 				element.sendKeys(a);
 				System.out.println("First Name (Invalid): " + a);
 				assertFalse(a.matches("[A-z][A-Za-z]"));
 				
 			}
 		
 		}
		
	}

	@When("^entered lastName$")
	public void entered_lastName() throws Throwable {
	   
	}

	@Then("^<Last name> is checked$")
	public void last_name_is_checked(DataTable arg1) throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.xpath("/html/body/div/form/input[2]"));
    	 List<String> list = arg1.asList(String.class);

 		List<String> l1 = arg1.asList(String.class);
 		l1.stream().forEach(System.out::println);
 		long c = l1.stream().count();

 		for(int i=0 ; i<c; i++)
 		{
 			String a = list.get(i);
 			System.out.println("First Name: " + a);

 			
 			if(a.matches("[A-z][A-Za-z]")){

 				element.sendKeys(a);
 				System.out.println("Last Name (valid): " + a);
 			assertTrue(a.matches("[A-z][A-Za-z]"));
 		}
 		
 			else {
 				element.sendKeys(a);
 				System.out.println("Last Name (Invalid): " + a);
 				assertFalse(a.matches("[A-z][A-Za-z]"));
 				
 			}
 		
 		}
	}
	@Given("^enter mobile number$")
	public void enter_mobile_number() throws Throwable {
	    
	}
	
	
	
	@Then("^<mob number> is checked$")
	public void mob_number_is_checked(DataTable arg1) throws Throwable {
	
		
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.name("mobile"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("mobile number - " + a);

			
			if(a.matches("[6-9][0-9]{9}")) {

				element.sendKeys(a);
				System.out.println("Mobile (valid): " + a);
			assertTrue(a.matches("[6-9][0-9]{9}"));

			}
			else{
				element.sendKeys(a);
				System.out.println("Mobile (Invalid): " + a);
			assertTrue(a.matches("[6-9][0-9]{9}"));

			}
		}
    	 
    
    	 
    	 
	}


}


