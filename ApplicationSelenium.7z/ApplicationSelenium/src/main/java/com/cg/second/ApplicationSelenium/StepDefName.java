package com.cg.second.ApplicationSelenium;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefName {
  
	@Given("^user is on web page$")
	public void user_is_on_web_page() throws Throwable {
	    
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 
	}

	

	@Given("^Enter firstName$")
	public void enter_firstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^check for Valid <firstName>$")
	public void check_for_Valid_firstName(DataTable arg1) throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.xpath("/html/body/div/form/input[1]"));
    	 List<String> list = arg1.asList(String.class);

 		List<String> l1 = arg1.asList(String.class);
 		l1.stream().forEach(System.out::println);
 		long c = l1.stream().count();

 		for(int i=0 ; i<c; i++)
 		{
 			String a = list.get(i);
 			System.out.println("First Nmae: " + a);

 			element.sendKeys(a);
 			

 			assertTrue(a.matches("[A-z][A-Za-z]"));

 		}
 		wb.close();
	}

	@Then("^check for Inalid <firstName>$")
	public void check_for_Inalid_firstName(DataTable arg1) throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.xpath("/html/body/div/form/input[1]"));
    	 List<String> list = arg1.asList(String.class);

 		List<String> l1 = arg1.asList(String.class);
 		l1.stream().forEach(System.out::println);
 		long c = l1.stream().count();

 		for(int i=0 ; i<c; i++)
 		{
 			String a = list.get(i);
 			System.out.println("First Nmae: " + a);

 			element.sendKeys(a);
 			

 			assertFalse(a.matches("[A-z][A-Za-z]"));

 		}
	
 		wb.close();
	}

	@Given("^Enter lastName$")
	public void enter_lastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^check for Valid <lastName>$")
	public void check_for_Valid_lastName(DataTable arg1) throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
		
		
		WebElement element = wb.findElement(By.xpath("/html/body/div/form/input[2]"));
		 List<String> list = arg1.asList(String.class);

	 		List<String> l1 = arg1.asList(String.class);
	 		l1.stream().forEach(System.out::println);
	 		long c = l1.stream().count();

	 		for(int i=0 ; i<c; i++)
	 		{
	 			String a = list.get(i);
	 			System.out.println("First Nmae: " + a);

	 			element.sendKeys(a);
	 			

	 			assertTrue(a.matches("[A-z][A-Za-z]"));

	 		}
	 		wb.close();
	}

	@Then("^check for Invalid <lastName>$")
	public void check_for_Invalid_lastName(DataTable arg1) throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
		
		
		WebElement element = wb.findElement(By.xpath("/html/body/div/form/input[2]"));
		 List<String> list = arg1.asList(String.class);

	 		List<String> l1 = arg1.asList(String.class);
	 		l1.stream().forEach(System.out::println);
	 		long c = l1.stream().count();

	 		for(int i=0 ; i<c; i++)
	 		{
	 			String a = list.get(i);
	 			System.out.println("First Nmae: " + a);

	 			element.sendKeys(a);
	 			

	 			assertFalse(a.matches("[A-z][A-Za-z]"));

	 		}
	
	 		wb.close();
	}
	@Given("^enter mobile number$")
	public void enter_mobile_number() throws Throwable {
	   
	   
	}

	@Then("^check for valid <mob number>$")
	public void check_for_valid_mob_number(DataTable arg1) throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.name("mobile"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("mobile number - " + a);

			element.sendKeys(a);
			

			assertTrue(a.matches("[0-9]{10}"));

		}
	   wb.close();
	}

	@Then("^check for Invalid <mobile number>$")
	public void check_for_Invalid_mobile_number(DataTable arg1) throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	 WebDriver wb= new ChromeDriver();
    	 wb.get("D:\\BDD\\application.html");
    	 WebElement element = wb.findElement(By.name("mobile"));
		List<String> list = arg1.asList(String.class);

		List<String> l1 = arg1.asList(String.class);
		l1.stream().forEach(System.out::println);
		long c = l1.stream().count();

		for(int i=0 ; i<c; i++)
		{
			String a = list.get(i);
			System.out.println("mobile number - " + a);

			element.sendKeys(a);
			

			assertFalse(a.matches("[0-9]{10}"));

		}
		wb.close();
		
	}

}
