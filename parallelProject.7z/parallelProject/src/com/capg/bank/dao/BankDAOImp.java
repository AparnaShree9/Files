package com.capg.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.capg.bank.beans.BankAccount;

public class BankDAOImp implements IBankDAO {
	 static List<BankAccount> custList = new ArrayList<BankAccount>();
	 static List<String> Trans = new ArrayList<String>();
	//static Map<Integer,Trans>trans= new HashMap<Integer,Trans>();

	BankAccount bank = new BankAccount(); 
  
	 
   @Override
	/*public BankAccount displayCustomer(int account_Number) {
		// TODO Auto-generated method stub
		
	   BankAccount cust = null;
		for(BankAccount b : custList){
			if(b.getAccount_Number() == account_Number){
				cust= b;
			}
		}
		System.out.println(cust);
		return cust;
	}
   */
   /*public boolean isValid(int account_Number,int pin_number){
	   boolean flag=false;
	   for (BankAccount b : custList) 
		 {
			if(b.getAccount_Number()==account_Number && b.getPin_Number()==pin_number)
			{
	   
	         flag = true;
			
			}
			 else{
			      System.err.println("RECHECK YOUR NUMBER");
					flag = false;
				 }
		 }
	   return flag;
	  
		 
   }*/
   public boolean isValid(int account_Number,int pin_number) {
	 
		   boolean flag=false;
	   
	       for (BankAccount b : custList) 
		   {
			if(b.getAccount_Number()==account_Number && b.getPin_Number()==pin_number)
			{
	   
	         flag = true;
			
			}
			 
		 }
	   return flag;
	   }
 public boolean isValid(int account_Number){
	   
	   boolean flag=false;
	   for (BankAccount b1 : custList) 
		 {
			if(b1.getAccount_Number()==account_Number)
			{
	   
	         flag = true;
			
			}
			/*else{
				 System.err.println("RECHECK YOUR Account NUMBER ");
			     flag = false;
		        }*/
		 }
	   System.out.println(flag);
	   return flag;
   }

   public boolean createAccount(BankAccount b){
	   boolean isAdded= false; 
		isAdded= custList.add(b);
	Trans.add(b.getAccount_balance()+"First balance");
		return isAdded;
		
	}

	 public double showBalance(int account_Number,int pin_number)
	 { double a=0.0;
		//BankAccount b = new BankAccount();
		
		for (BankAccount b : custList) {
			
	     if(b.getAccount_Number()==account_Number && b.getPin_Number()==pin_number)
		 {
			
				  a = b.getAccount_balance() ;	
				  System.out.println("Your account balance is: " + a);
				 //System.out.println(b);
		}
		}
		 return a;
				
				
				
	 }
	
	 public double deposit(int account_Number ,double depamt){
		
	   double a=0.0;
	   for (BankAccount b : custList) 
		 {
			if(b.getAccount_Number()==account_Number)
			{
				a= b.getAccount_balance();
				a=a+depamt;
				b.setAccount_balance(a);
				Trans.add(b.getAccount_balance()+"Deposited");
				/*StringBuffer r = new StringBuffer();
				   StringBuffer s = r.append("You deposited Rs"+ depamt );
			       b.setTransaction(s); */
			}
			/*else if(b.getAccount_Number()!=account_Number){
				 System.out.println("re enter your number");
			     a=0.00;
		        }*/
		 }
	       
	   System.out.println("Your new Balance is "+a);
	   return a;
	   
 }
	
	 public double withdraw(int account_Number,int pin_number, double widAmt){
		 double a=1.0;
		   for (BankAccount b : custList) 
			 {
				if(b.getAccount_Number()==account_Number)
				{
					a= b.getAccount_balance();
					a=a - widAmt;
					b.setAccount_balance(a);
					Trans.add(b.getAccount_balance()+"Withdrawn");
				}
				/*else{
					 System.err.println("re enter your number");
				     a=0.00;
			        }*/
			 }
		
		   System.out.println("Your new Balance is "+a);
		   return a;
	 }
	 
	 public double fundTransfer(int account_Number,int account_Number2,int pin_number, double tAmt){
		 double a= 0.0;
		 double k =0.0;
		   for (BankAccount b : custList) 
			 {
				if(b.getAccount_Number()==account_Number &&b.getPin_Number()==pin_number )
				{
					a= b.getAccount_balance();
					if(a>tAmt)
					{
						a= a-tAmt;
						b.setAccount_balance(a);
						Trans.add(b.getAccount_balance()+"transferred");
						for (BankAccount b1 : custList) 
						{
							if(b1.getAccount_Number()==account_Number2 )
							{
								k=b1.getAccount_balance();
								k = k+tAmt;
								b1.setAccount_balance(k);
								System.out.println(b1);
								Trans.add(b1.getAccount_balance()+"Deposited");
							}
						}
					System.out.println("this is b" + b);
					}
					
					else 
						System.out.println("can't transfer");
					/*
					a=a - widAmt;
					b.setAccount_balance(a);
				*/
				}
				/*else{
					 System.err.println("re enter your number");
				     a=0.00;
			        }*/
			 }
		
		   System.out.println("Your new Balance is "+a);
		   return a;
		 
	 }
	 public String printTransactions(int account_Number,int pin_number){
		 String c=null;
		 Iterator<String> it = Trans.iterator();
			while (it.hasNext()){
				c =it. next();
				System.out.println(c);
				}
			
	 return c;
		 
		 
		 
	 }
	/* public StringBuffer printTransactions(int account_Number,int pin_number){
		 StringBuffer s = null;
		 for (BankAccount b : custList) {
			s= b.getTransaction();
			BankDAOImp.custList
			System.out.println(s);
		 }
		 return s;
	 
		 }*/
}
