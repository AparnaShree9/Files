package com.capg.bank.service;

import com.capg.bank.beans.BankAccount;

public interface IBankService {
	
	 public boolean createAccount(BankAccount b);
	
	 public double showBalance(int account_Number,int pin_number);
	 
	 public boolean isValid(int account_Number,int pin_number);
	public boolean isValid(int account_Number);
	
	 
	 public double deposit(int account_Number,double depamt);
	 
	 public double withdraw(int account_Number,int pin_number,double widAmt);
	 
	 public double fundTransfer(int account_Number,int account_Number2,int pin_number, double tAmt);
	 
	 public String printTransactions(int account_Number,int pin_number);
	//public BankAccount displayCustomer(int account_Number);
}
