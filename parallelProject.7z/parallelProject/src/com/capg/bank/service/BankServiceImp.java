package com.capg.bank.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.dao.BankDAOImp;
import com.capg.bank.exception.MyException;

public class BankServiceImp implements IBankService {
	
	BankDAOImp dao = new BankDAOImp();
	
	public boolean createAccount(BankAccount b){
		
		return dao.createAccount(b);
		}

	 public double showBalance(int account_Number,int pin_number){
		 
		return	 dao.showBalance(account_Number, pin_number); 
	 }
	 
	 public boolean isValid(int account_Number,int pin_number){
		 
		 return	 dao.isValid(account_Number, pin_number);
	 }
	 
		public boolean isValid(int account_Number){
			
			return	 dao.isValid(account_Number);
		}
     
	 public double deposit(int account_Number, double depamt){
		 
		 return dao.deposit(account_Number, depamt);
	 
	 }
	 
	 public double withdraw(int account_Number,int pin_number,double widAmt){
		 
		return dao.withdraw(account_Number,pin_number,widAmt);
		 
	 }
	 
	 public double fundTransfer(int account_Number,int account_Number2,int pin_number, double tAmt){
		 
		return dao.fundTransfer(account_Number,account_Number2,pin_number,tAmt);
		 
	 }
	 
	 public String printTransactions(int account_Number,int pin_number){
		 
		 
			return dao.printTransactions(account_Number,pin_number);
	 
		 }
	 
	/* public BankAccount displayCustomer(int account_Number)
	 {
		 return dao.displayCustomer(account_Number);
	 }*/
}
