package com.capg.bank.exception;

public class MyException extends Exception {
         
}
