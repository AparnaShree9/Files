package com.capg.bank.ui;
import java.util.Random;
import java.util.Scanner;

import com.capg.bank.beans.BankAccount;
import com.capg.bank.service.BankServiceImp;

public class Client {
	
	public static int getRandomNumberInts(int min, int max){
	    Random random = new Random();
	    int accNumber= random.ints(min,(max+1)).findFirst().getAsInt();
	    return accNumber;  
	    
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        System.out.println("Welcome to XYZ bank");
        System.out.println("_____________________");
        while (true){
		System.out.println("Choose the services you want to avail");
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.Exit");
		System.out.println("Enter your choice :");
		   Scanner sc = new Scanner(System.in);
		        int n = sc.nextInt();
		                  Client dm = new Client();
		              BankAccount bean = new BankAccount();
		            BankServiceImp service = new BankServiceImp();
		     switch (n) {
			case 1:
				   System.out.println("Enter your name:");
				   String cname = sc.next();
				   System.out.println("Give your permanent government ID: ");
				   String cid = sc.next();
				   System.out.println("enter your age:");
				   int age = sc.nextInt();
				   System.out.println("Enter your address :");
				      StringBuffer b = new StringBuffer();
			          System.out.println("city");
			          
			              b.append(sc.next());
			              b.append(" ,");
			          System.out.println("State");
			              b.append(sc.next());
			              b.append(" ,");
			          System.out.println("Pin no.");
			          StringBuffer w = b.append(sc.next());
			          
			   
				   System.out.println("Enter your mobile number");
				   String number = sc.next();
           
				           bean.setCustomer_name(cname);
				           bean.setCustomer_id(cid);
				           bean.setAge(age);
				           bean.setCustomer_address(w);
				           bean.setCustomer_mobileNumber(number);
		           System.out.println("Enter the minimum balance for your account");
		                   double amt =sc.nextDouble();
		                   bean.setAccount_balance(amt);
		                   
			       System.out.println("Congratulations ! Your account has been created");
			      
			       int acc = (dm.getRandomNumberInts(100000, 1000000));
			       bean.setAccount_Number(acc);
			      /* System.out.println(bean);*/
			        boolean isAdded= service.createAccount(bean);
			        if(isAdded){
		
	    		    System.out.println("record added succesfully");
	    		    System.out.println("your Account number is " + acc );
		             
			        }
			        
			       int pin = (dm.getRandomNumberInts(1000, 5000));
			       System.out.println("your PIN number is " + pin );
			              bean.setPin_Number(pin);
			       System.out.println(bean);
				  /* StringBuffer p = new StringBuffer();
				   StringBuffer q = p.append("Your Transaction Rs"+ amt +" deposited");
			       bean.setTransaction(q);*/
			       
			       break;
			
				
				
            case 2:
				   System.out.println("Enter your account number");
				          int accNum= sc.nextInt();
				          
				          System.out.println("Enter your PIN");
				          int pn= sc.nextInt();
				          boolean valid= service.isValid(accNum,pn);
				         
				             //service.displayCustomer(accNum);
				          service.showBalance(accNum, pn);
				        	//System.out.println();
				         
				        
				   break;
            case 3:
            	
            	System.out.println("Enter your account number");
            	int acNum = sc.nextInt();
            	boolean valid1= service.isValid(acNum);
            	if(valid1){
            	        System.out.println("Enter the amount to be deposited");
            	        double depamt = sc.nextDouble();
            	        double newbal =service.deposit(acNum, depamt);
            	        
            	     //bean.setAccount_balance(newbal);
            	  
            	}
            	break;
           
            case 4:
            	System.out.println("Enter your account number");
		          int accNum1= sc.nextInt();
		          
		          System.out.println("Enter your PIN");
		          int pn1= sc.nextInt();
		          boolean valid2= service.isValid(accNum1,pn1);
		          
		          
		          if(valid2){
	
		          System.out.println("Enter the amount you want to withdraw");
		          double widAmt= sc.nextDouble();
            	  double newbal2=service.withdraw(accNum1, pn1, widAmt);
		         // bean.setAccount_balance(newbal2);
		        
		          }
				break;
            case 5:
            	System.out.println("Enter your account number");
				int accnumf = sc.nextInt();
				System.out.println("Enter your PIN");
				int fpin = sc.nextInt();
				boolean valid3= service.isValid(accnumf,fpin);
				if(valid3){
				            System.out.println("Enter beneficiary's account number");
				            int accnums = sc.nextInt();
				            boolean valid4 = service.isValid(accnums);
				             if(valid4){
					             System.out.println("Enter the amount to be transferred");
					             double tAmt = sc.nextDouble();
					             double newbal3 = service.fundTransfer(accnumf, accnums, fpin, tAmt);
				             }
				  }
				/*int accnums = sc.nextInt();
				boolean valid4 = service.isValid(accnums);
				if(valid4){
					System.out.println("Enter the amount to be transferred");
		             double tAmt = sc.nextDouble();
		             double newbal3 = service.fundTransfer(accnumf, accnums, fpin, tAmt);
					
				}*/
				
				break;
            case 6:
            	System.out.println("Enter your account number");
				int accnumt = sc.nextInt();
				System.out.println("Enter your PIN");
				int pint = sc.nextInt();
				boolean valid5= service.isValid(accnumt,pint);
				if(valid5){
					System.out.println("Your Transaction Details: ");
					String l = service.printTransactions(accnumt,pint);
				}
				break;
            case 7:
            	System.exit(0);
				break;	
			default:
				break;
			}

	}

}
}
