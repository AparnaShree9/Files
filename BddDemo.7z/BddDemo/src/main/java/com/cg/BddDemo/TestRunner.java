package com.cg.BddDemo;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;


//@RunWith(Cucumber.class)
@CucumberOptions(features="test/resources", glue="test/java")
public class TestRunner {
	
}
