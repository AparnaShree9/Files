package com.cg.BddDemo;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class StepDef {

	@Given("^enter username and password$")
	public void enter_username_and_password() throws Throwable {
	  System.out.println("User name");
	    throw new PendingException();
	}

	@Then("^navigate to main page$")
	public void navigate_to_main_page() throws Throwable {
		 System.out.println("main Page");
	    throw new PendingException();
	}
	
}
