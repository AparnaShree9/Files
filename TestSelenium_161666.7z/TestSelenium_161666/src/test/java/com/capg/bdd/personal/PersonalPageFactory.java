package com.capg.bdd.personal;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PersonalPageFactory {

	WebDriver wd;
	
	
	@FindBy(how= How.ID,using= "txtFirstName")
	@CacheLookup
	WebElement firstName;
	@FindBy(how= How.ID,using= "txtLastName")
	@CacheLookup
	WebElement lastName;
	@FindBy(how= How.ID,using= "txtEmail")
	@CacheLookup
	WebElement email;
	@FindBy(how= How.ID,using= "txtPhone")
	@CacheLookup
	WebElement contact;
	@FindBy(how= How.NAME,using= "address1")
	@CacheLookup
	WebElement addLine1;
	@FindBy(how= How.NAME,using= "address2")
	@CacheLookup
	WebElement addLine2;
	@FindBy(how= How.NAME,using= "city")
	@CacheLookup
	WebElement dropCity;
	@FindBy(how= How.NAME,using= "state")
	@CacheLookup
	WebElement dropState;
	@FindBy(how= How.XPATH,using= "/html/body/form/table/tbody/tr[11]/td/a")
	@CacheLookup
	WebElement next;
	
	
	
	
	
	public PersonalPageFactory() {
		super();
	}
	
	public PersonalPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	
	}
	
	
	
	public WebElement getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public WebElement getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);;
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}
	public WebElement getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact.sendKeys(contact);;
	}
	public WebElement getAddLine1() {
		return addLine1;
	}
	public void setAddLine1(String addLine1) {
		this.addLine1.sendKeys(addLine1);;
	}
	public WebElement getAddLine2() {
		return addLine2;
	}
	public void setAddLine2(String addLine2) {
		
		this.addLine2.sendKeys(addLine2);
	}
	public WebElement getDropCity() {
		return dropCity;
	}
	public void setDropCity(String dropCity) {
		Select city=new Select(wd.findElement(By.name("city")));
		
		city.selectByVisibleText(dropCity);
	
		this.dropCity.sendKeys(dropCity);
	}
	public WebElement getDropState() {
		return dropState;
	}
	public void setDropState(String dropState) {
		Select city=new Select(wd.findElement(By.name("state")));
		
		city.selectByVisibleText(dropState);
		this.dropState.sendKeys(dropState);
	}
	public WebElement getNext() {
		return next;
	}
	public void setNext() {
		this.next.click();
	}




}
