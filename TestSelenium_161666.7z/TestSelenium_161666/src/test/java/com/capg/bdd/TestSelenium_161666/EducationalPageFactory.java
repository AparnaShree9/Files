package com.capg.bdd.TestSelenium_161666;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EducationalPageFactory {

	WebDriver wd;
	@FindBy(how= How.NAME,using= "graduation")
	@CacheLookup
	WebElement dropGraduation;
	@FindBy(how= How.ID,using= "txtPercentage")
	@CacheLookup
	WebElement percentage;
	@FindBy(how= How.ID,using= "txtPassYear")
	@CacheLookup
	WebElement passingYear;
	@FindBy(how= How.ID,using= "txtProjectName")
	@CacheLookup
	WebElement projectName;
	@FindBy(how= How.ID,using= "cbTechnologies")
	@CacheLookup
	List<WebElement> checkTech;
	@FindBy(how= How.ID,using= "txtOtherTechs")
	@CacheLookup
	WebElement other;
	@FindBy(how= How.ID,using= "btnRegister")
	@CacheLookup
	WebElement Register;
	
	
	
	
	
	public EducationalPageFactory() {
		super();
	}
	
	public EducationalPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	
	
	public WebElement getDropGraduation() {
		return dropGraduation;
	}
	public void setDropGraduation(String dropGraduation) {
		Select city=new Select(wd.findElement(By.name("graduation")));
		city.selectByVisibleText(dropGraduation);
	
	}
	public WebElement getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}
	public WebElement getPassingYear() {
		return passingYear;
	}
	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);;
	}
	public WebElement getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}
	public List<WebElement> getCheckTech() {
		return checkTech;
	}
	public void setCheckTech(List<Integer> checkTech) {
		Iterator<Integer> it = checkTech.iterator();
		while(it.hasNext()) {
			int a= it.next();
			if(a==1) 
				this.checkTech.get(0).click();
			if(a==2)
				this.checkTech.get(1).click();
		    if(a==3) {
			this.checkTech.get(2).click();
		   
		    }if(a==4) {
		    	
				this.checkTech.get(3).click();
		    
		    
		    
		    
		    }else {}
		   
		
		}
	}
	public WebElement getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other.sendKeys(other);
	}
	public WebElement getRegister() {
		return Register;
	}
	public void setRegister() {
		Register.click();
	}



}
