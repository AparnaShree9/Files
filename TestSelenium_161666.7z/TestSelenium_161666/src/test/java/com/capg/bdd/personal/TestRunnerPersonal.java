package com.capg.bdd.personal;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty","json:TestResults1/HtmlResults1"})
public class TestRunnerPersonal {

}
