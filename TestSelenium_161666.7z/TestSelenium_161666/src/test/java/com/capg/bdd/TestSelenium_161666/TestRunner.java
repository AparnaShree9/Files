package com.capg.bdd.TestSelenium_161666;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty","json:TestResults/HtmlResults"})
public class TestRunner {

}
