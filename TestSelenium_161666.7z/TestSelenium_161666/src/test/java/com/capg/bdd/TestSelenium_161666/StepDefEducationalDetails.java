package com.capg.bdd.TestSelenium_161666;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefEducationalDetails {

	private WebDriver driver;
	
	private EducationalPageFactory pageFactory;
	
	
	@When("^user matches the tite$")
	public void user_matches_the_tite() throws Throwable {
		 driver.getTitle();
	}

	@Then("^the title is matched$")
	public void the_title_is_matched() throws Throwable {
	    Assert.assertEquals(driver.getTitle(),"Educational Details");
	}

	@Given("^user is on Educational Details page$")
	public void user_is_on_Educational_Details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\\\\\\\Users\\\\\\\\apshree\\\\\\\\Desktop\\\\\\\\chromedriver.exe");
		driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 pageFactory = new EducationalPageFactory(driver); 
		driver.get("file:///D:/BDD/MPT/SET03/WebPages/EducationalDetails.html");
	}
	
	
	@When("^user does not select valid graduation$")
	public void user_does_not_select_valid_graduation() throws Throwable {
			pageFactory.setDropGraduation("");
		    Thread.sleep(1000);
		    pageFactory.setPercentage("80");
		    Thread.sleep(1000);
		    pageFactory.setPassingYear("2018");
		    Thread.sleep(1000);
		    pageFactory.setProjectName("Bank Account");
		    Thread.sleep(1000);
		    List<Integer>lang = new ArrayList<Integer>();
		    lang.add(1);
		    lang.add(2);
		    pageFactory.setCheckTech(lang);
		    Thread.sleep(1000);
		    pageFactory.setRegister();
		    Thread.sleep(1000);
	}

	@When("^clicks on register me$")
	public void clicks_on_register_me() throws Throwable {
	   pageFactory.setRegister();
	}

	@Then("^display alert$")
	public void display_alert() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alert);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user does not enter percentage$")
	public void user_does_not_enter_percentage() throws Throwable {
		 pageFactory.setDropGraduation("BE");
		    Thread.sleep(1000);
		    pageFactory.setPercentage("");
		    Thread.sleep(1000);
		    pageFactory.setPassingYear("2018");
		    Thread.sleep(1000);
		    pageFactory.setProjectName("Bank Account");
		    Thread.sleep(1000);
		    List<Integer>lang = new ArrayList<Integer>();
		    lang.add(1);
		    lang.add(2);
		    pageFactory.setCheckTech(lang);
		    Thread.sleep(1000);
		    pageFactory.setRegister();
		    Thread.sleep(1000);
	}

	@When("^clicks on make payment$")
	public void clicks_on_make_payment() throws Throwable {
	   
	}

	@When("^user does not enter passing year$")
	public void user_does_not_enter_passing_year() throws Throwable {
		 pageFactory.setDropGraduation("BE");
		    Thread.sleep(1000);
		    pageFactory.setPercentage("80");
		    Thread.sleep(1000);
		    pageFactory.setPassingYear("");
		    Thread.sleep(1000);
		    pageFactory.setProjectName("Bank Account");
		    Thread.sleep(1000);
		    List<Integer>lang = new ArrayList<Integer>();
		    lang.add(1);
		    lang.add(2);
		    pageFactory.setCheckTech(lang);
		    Thread.sleep(1000);
		    pageFactory.setRegister();
		    Thread.sleep(1000);
	}

	@When("^user does not enter project name$")
	public void user_does_not_enter_project_name() throws Throwable {
		 pageFactory.setDropGraduation("BE");
		    Thread.sleep(1000);
		    pageFactory.setPercentage("80");
		    Thread.sleep(1000);
		    pageFactory.setPassingYear("2018");
		    Thread.sleep(1000);
		    pageFactory.setProjectName("");
		    Thread.sleep(1000);
		    List<Integer>lang = new ArrayList<Integer>();
		    lang.add(1);
		    lang.add(2);
		    pageFactory.setCheckTech(lang);
		    Thread.sleep(1000);
		    pageFactory.setRegister();
		    Thread.sleep(1000);
	}

	@When("^user does not select the technology used$")
	public void user_does_not_select_the_technology_used() throws Throwable {
		 pageFactory.setDropGraduation("BE");
		    Thread.sleep(1000);
		    pageFactory.setPercentage("80");
		    Thread.sleep(1000);
		    pageFactory.setPassingYear("2018");
		    Thread.sleep(1000);
		    pageFactory.setProjectName("Bank Account");
		    Thread.sleep(1000);
		    List<Integer>lang = new ArrayList<Integer>();
		   
		    pageFactory.setCheckTech(lang);
		    Thread.sleep(1000);
		    pageFactory.setRegister();
		    Thread.sleep(1000);
	}

	@When("^user select the other technology used$")
	public void user_select_the_other_technology_used() throws Throwable {
		 pageFactory.setDropGraduation("BE");
		    Thread.sleep(1000);
		    pageFactory.setPercentage("80");
		    Thread.sleep(1000);
		    pageFactory.setPassingYear("2018");
		    Thread.sleep(1000);
		    pageFactory.setProjectName("Bank Account");
		    Thread.sleep(1000);
		    List<Integer>lang = new ArrayList<Integer>();
		    lang.add(4);
		    
		    pageFactory.setCheckTech(lang);
		    Thread.sleep(1000);
		    pageFactory.setRegister();
		    Thread.sleep(1000);
	}

	@When("^leave the name of technology field empty$")
	public void leave_the_name_of_technology_field_empty() throws Throwable {
		 pageFactory.setDropGraduation("BE");
		    Thread.sleep(1000);
		    pageFactory.setPercentage("80");
		    Thread.sleep(1000);
		    pageFactory.setPassingYear("2018");
		    Thread.sleep(1000);
		    pageFactory.setProjectName("Bank Account");
		    Thread.sleep(1000);
		    List<Integer>lang = new ArrayList<Integer>();
		    lang.add(4);
		    
		    pageFactory.setCheckTech(lang);
		    Thread.sleep(1000);
		    pageFactory.setOther("");
		    pageFactory.setRegister();
		    Thread.sleep(1000);
	}

	@When("^all the valid educational details are entered$")
	public void all_the_valid_educational_details_are_entered() throws Throwable {
	    pageFactory.setDropGraduation("BE");
	    Thread.sleep(1000);
	    pageFactory.setPercentage("80");
	    Thread.sleep(1000);
	    pageFactory.setPassingYear("2018");
	    Thread.sleep(1000);
	    pageFactory.setProjectName("Bank Account");
	    Thread.sleep(1000);
	    List<Integer>lang = new ArrayList<Integer>();
	    lang.add(1);
	    lang.add(2);
	    pageFactory.setCheckTech(lang);
	    Thread.sleep(1000);
	    pageFactory.setRegister();
	    Thread.sleep(1000);
	}


}
