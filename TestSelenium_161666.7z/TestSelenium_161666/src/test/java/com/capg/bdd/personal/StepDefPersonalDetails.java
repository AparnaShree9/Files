package com.capg.bdd.personal;

import java.util.concurrent.TimeUnit;



import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;


public class StepDefPersonalDetails {
	private WebDriver driver;
	private PersonalPageFactory pageFactory;
	
	
	@Given("^user is on Personal Details page$")
	public void user_is_on_Personal_Details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\apshree\\\\Desktop\\\\chromedriver.exe");
		driver = new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		 pageFactory = new PersonalPageFactory(driver);
		driver.get("file:///D:/BDD/MPT/SET03/WebPages/PersonalDetails.html");
	}
	
	@When("^user left the firstname field empty$")
	public void user_left_the_firstname_field_empty() throws Throwable {
	    pageFactory.setFirstName("");
	    Thread.sleep(1000);
	}

	@When("^clicks on next$")
	public void clicks_on_next() throws Throwable {
	   pageFactory.setNext(); 
	}

	@Then("^display display alert$")
	public void display_display_alert() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alert);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user left the lastname field empty$")
	public void user_left_the_lastname_field_empty() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("9632587412");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc");
		Thread.sleep(1000);
		pageFactory.setContact("9632587412");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}

	@When("^user left the contact number field empty$")
	public void user_left_the_contact_number_field_empty() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}

	@When("^user enters wrong contact number$")
	public void user_enters_wrong_contact_number() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("9632");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}

	@When("^user left the adresslinefirst field empty$")
	public void user_left_the_adresslinefirst_field_empty() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("9632587412");
		Thread.sleep(1000);
		pageFactory.setAddLine1("");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}

	@When("^user left the adresslinesecond field empty$")
	public void user_left_the_adresslinesecond_field_empty() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("9632587412");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}



	@When("^user does not select the state$")
	public void user_does_not_select_the_state() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("9632587412");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("");
	}

	@When("^user enters all valid details$")
	public void user_enters_all_valid_details() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("9632587412");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("Chennai");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}

	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
	 driver.get("file:///D:/BDD/MPT/SET03/WebPages/EducationalDetails.html");
	 driver.close();
	}

	@When("^user checks the tite$")
	public void user_checks_the_tite() throws Throwable {
	   driver.getTitle();
	}

	@Then("^title is matched$")
	public void title_is_matched() throws Throwable {
		  Assert.assertEquals(driver.getTitle(), "Personal Details");
	}

	@When("^user does not select the city$")
	public void user_does_not_select_the_city() throws Throwable {
		pageFactory.setFirstName("King");
		Thread.sleep(1000);
		pageFactory.setLastName("Khan");
		Thread.sleep(1000);
		pageFactory.setEmail("abc@gmail.com");
		Thread.sleep(1000);
		pageFactory.setContact("9632587412");
		Thread.sleep(1000);
		pageFactory.setAddLine1("Siruseri");
		Thread.sleep(1000);
		pageFactory.setAddLine2("chennai");
		Thread.sleep(1000);
		pageFactory.setDropCity("");
		Thread.sleep(1000);
		pageFactory.setDropState("Tamilnadu");
	}

}
